extends OldEnemy3D

## Chaser
## Chases after player in a straight line. Disappears after the light shines on it for a period of time.
## Gets faster for each page collected.

# movement constants
const BASE_SPEED: float = 4.75
const LIGHT_SPEED_PENALTY: float = 2.5
const RUN_SPEED_MULTIPLIER: float = 15.0

# chase timing constants
const BASE_CHASE_TIME: float = 3.0

# state management
enum State { CHASING, FLEEING, DISABLED }
var current_state: State = State.CHASING
var is_lit: bool = false
var remaining_chase_time: float = 0.0
var fleeing: bool = false

# onready references
@onready var player: CharacterBody3D = get_tree().get_first_node_in_group("Player")
@onready var nav_agent: NavigationAgent3D = $NavigationAgent3D
@onready var ambient_music: AudioStreamPlayer3D = $"Ambient"
@onready var sprite: AnimatedSprite3D = $Sprite3D
@onready var pathfinding_component: PathfindingComponent = $PathfindingComponent

func _ready() -> void:
	setup_signals()
	play_spawn_animation()
	initialize_chase_time()

func _process(delta: float) -> void:
	update_light_state(delta)

func _physics_process(delta: float) -> void:
	apply_gravity(delta)
	
	if not player or current_state == State.DISABLED:
		return
	
	move_and_slide()
	check_player_collision()


## initialization
func setup_signals() -> void:
	Signals.player_died.connect(die)

func play_spawn_animation() -> void:
	var original_scale = sprite.scale
	sprite.scale = Vector3.ZERO
	var tween = create_tween()
	tween.tween_property(sprite, "scale", original_scale, 0.25).set_trans(Tween.TRANS_CUBIC)

func initialize_chase_time() -> void:
	remaining_chase_time = calculate_chase_time()


## main update logic
# called every 6 ticks by PathfindingComponent
func pathfind() -> void:
	update_navigation()
	update_movement()

func update_light_state(delta: float) -> void:
	if is_lit and current_state == State.CHASING:
		remaining_chase_time -= delta
		sprite.start_shake(0.1)
		
		if remaining_chase_time <= 0:
			begin_fleeing()
	else:
		sprite.stop_shake()

func apply_gravity(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta

func update_navigation() -> void:
	nav_agent.target_position = player.global_position

func update_movement() -> void:
	match current_state:
		State.CHASING:
			move_toward_player()
		State.FLEEING:
			velocity = Vector3.ZERO

func move_toward_player() -> void:
	if nav_agent.is_navigation_finished():
		return
	
	var next_position = nav_agent.get_next_path_position()
	var direction = (next_position - global_position).normalized()
	velocity = direction * calculate_speed()

func move_away_from_player() -> void:
	var direction = (global_position - player.global_position).normalized()
	velocity = direction * (calculate_speed() * RUN_SPEED_MULTIPLIER)


## state changes
func begin_fleeing() -> void:
	current_state = State.FLEEING
	play_flee_audio()
	play_shrink_animation()

func play_flee_audio() -> void:
	ambient_music.stream = preload("uid://b3sk41yuadbx2")
	ambient_music.play(0.05)
	create_tween().tween_property(ambient_music, "volume_db", -20, 0.5).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_SINE)

func play_shrink_animation() -> void:
	var tween = create_tween()
	tween.tween_property(sprite, "scale", Vector3(1, 0.01, 1), 0.5).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_BACK)
	tween.finished.connect(on_flee_complete)

func on_flee_complete() -> void:
	died.emit()
	queue_free()


## calculations
func calculate_speed() -> float:
	var base = BASE_SPEED
	var penalty = LIGHT_SPEED_PENALTY if is_lit else 0.0
	return base - penalty

func calculate_chase_time() -> float:
	return BASE_CHASE_TIME


## public
func set_targeted(active: bool) -> void:
	is_lit = active
	
	match is_lit:
		true:
			$Sprite3D.animation = "blinded"
		false:
			$Sprite3D.animation = "walk"

func die(_killer_name: String = "") -> void:
	died.emit()
	queue_free()
