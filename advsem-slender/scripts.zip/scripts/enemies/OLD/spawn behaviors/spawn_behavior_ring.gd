class_name SpawnRing extends SpawnBehavior

## Gets a ring around the player and spawns at a random point along it.

@export var radius: float = 25.0

func get_spawn_position(player: CharacterBody3D) -> Vector3:
	var angle = randf_range(0, TAU)
	
	print(player.global_position)
	print(angle)
	
	var x = radius * cos(angle)
	var z = radius * sin(angle)
	
	var pos = player.global_position + Vector3(x, 0, z)
	
	print(pos)
	return pos
