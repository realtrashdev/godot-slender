class_name VesselProfile extends CharacterProfile

@export var stats: PlayerStats

@export_group("Items")
@export var starting_items: Array
