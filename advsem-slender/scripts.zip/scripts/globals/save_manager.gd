extends Node

const SAVE_PATH = "user://save_data.page"
const SAVE_VERSION = "0.0"

func _ready():
	load_game()

func save_game():
	var save_dict = {
		"settings": Settings.data,
		"progression": Progression.data,
		"version": SAVE_VERSION
	}
	
	var file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	
	if file:
		file.store_var(save_dict)
		file.close()
		print("Game saved successfully")
	else:
		push_error("Failed to save game")

func load_game():
	if not FileAccess.file_exists(SAVE_PATH):
		print("No save file found, using defaults")
		return
	
	var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if not file:
		push_error("Failed to open save file")
		return
	
	var data = file.get_var()
	file.close()
	
	if typeof(data) != TYPE_DICTIONARY:
		push_error("Save file corrupted or wrong format")
		return
	
	var version = data.get("version", "unknown")
	if version != SAVE_VERSION:
		print("Save version mismatch (file: %s, current: %s)" % [version, SAVE_VERSION])
	
	if data.has("settings"):
		Settings.data = data["settings"]
	
	if data.has("progression"):
		Progression.data = data["progression"]
	
	print("Game loaded successfully")

func reset_progression():
	Progression.reset_to_defaults()
	save_game()

func reset_settings():
	Settings.reset_to_defaults()
	save_game()

func reset_all_data():
	Progression.reset_to_defaults()
	Settings.reset_to_defaults()
	save_game()

#func _notification(what: int) -> void:
	#if what == NOTIFICATION_WM_CLOSE_REQUEST:
		#print("GAME CLOSING - WM_CLOSE_REQUEST received!")
		#print("Stack trace:")
		#print_stack()
