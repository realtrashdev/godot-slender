extends Node

const SAVE_PATH: String = "user://endless.page"

var enemy_list: Dictionary[int, EnemyProfileList]

func _ready():
	load_data()

#region Saving
func save_data():
	var save_dict = {
		"enemies": enemy_list,
		"version": SaveManager.SAVE_VERSION
	}
	
	var file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	
	if file:
		file.store_var(save_dict)
		file.close()
		print("Endless saved successfully")
	else:
		push_error("Failed to save Endless")

func load_data():
	if not FileAccess.file_exists(SAVE_PATH):
		print("No Endless save file found, using defaults")
		return
	
	var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if not file:
		push_error("Failed to open Endless save file")
		return
	
	var data = file.get_var()
	file.close()
	
	if typeof(data) != TYPE_DICTIONARY:
		push_error("Endless file corrupted or wrong format")
		return
	
	var version = data.get("version", "unknown")
	if version != SaveManager.SAVE_VERSION:
		print("Endless save version mismatch (file: %s, current: %s)" % [version, SaveManager.SAVE_VERSION])
	
	if data.has("enemies"):
		enemy_list = data["enemies"]
	
	print("Endless save loaded successfully")

func reset_all_data():
	enemy_list = {}
	save_data()
#endregion


func get_enemy_list() -> Dictionary[int, EnemyProfileList]:
	return enemy_list


func set_enemy_list(new_list: Dictionary[int, EnemyProfileList]):
	enemy_list = new_list


func add_enemy_to_list(page_count: int, enemy: EnemyProfile):
	enemy_list[page_count].profiles.append(enemy)
	print("Enemy added to enemy_list: %s at page_count %s" % [enemy.name, page_count])
