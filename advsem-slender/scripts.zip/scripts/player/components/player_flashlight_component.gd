class_name PlayerFlashlightComponent extends Node

signal target_brightness_reached

const PAGE_LIGHT_DOWN_TIME: float = 1.0

const PASSIVE_FLICKER_AMOUNT: float = 0.2

const DEFAULT_SPRINT_ANGLE: float = -60
const TURN_ON_ANGLE: Vector2 = Vector2(-60, -30)
const CAMERA_SMOOTHING = 10

const ATTRACTION_MAX_ANGLE: float = 25.0
const ATTRACTION_SMOOTHING: float = 12.0

@export var flicker_sound: AudioStream
var flickering: bool = false

var light_brightness: float = 2.0

var light_on: bool = false
var passive_flicker: bool = false
var sprint_angle: float = -60
var rotation_override: float = 0
var sprint_angle_modifier: float = 20
var flashlight_offset := Vector3(0, 0, 0)
var time_count: float
var battery_alive: bool = true

var target_brightness: float

var player: Player
var head: Node3D
var restriction_component: PlayerRestrictionComponent
var movement_component: PlayerMovementComponent
var camera_component: PlayerCameraComponent

@onready var flashlight: Node3D
@onready var light: SpotLight3D
@onready var audio_source: AudioStreamPlayer
@onready var omni_light: OmniLight3D
@onready var interaction_cast: RayCast3D
@onready var enemy_cast: RayCast3D


func _ready() -> void:
	Signals.page_collected.connect(on_page_collected)
	Signals.enemy_spawned.connect(on_enemy_spawned)
	
	Signals.radar_charged.connect(_on_radar_charged)
	Signals.radar_died.connect(_on_radar_died)
	
	player = get_parent()
	restriction_component = player.get_node("RestrictionComponent")
	movement_component = player.get_node("MovementComponent")
	camera_component = player.get_node("CameraComponent")
	
	head = player.get_node("Head")
	flashlight = player.get_node("Head/Flashlight")
	light = flashlight.get_node("SpotLight3D")
	audio_source = flashlight.get_node("FlashlightAudio")
	omni_light = flashlight.get_node("OmniLight3D")
	interaction_cast = player.get_node("Head/Camera3D/RayCast3D")
	enemy_cast = player.get_node("Head/RayCast3D")
	
	_apply_base_character_stats()
	light.light_energy = light_brightness
	target_brightness = light_brightness
	sprint_angle = get_sprint_angle()
	if not player.instant_activate:
		call_deferred("deactivate")


func _process(delta: float) -> void:
	time_count += delta
	enemy_cast.enabled = light_on and !movement_component.is_sprinting()
	
	if Input.is_action_just_pressed("toggle_light") and battery_alive:
		toggle_light(!light_on)


func _physics_process(delta: float) -> void:
	if player.radar.is_battery_low() and not flickering:
		target_brightness += randf_range(-PASSIVE_FLICKER_AMOUNT / 10, PASSIVE_FLICKER_AMOUNT / 5)
		if target_brightness > light_brightness:
			target_brightness = light_brightness
	elif not flickering:
		target_brightness = light_brightness


func _apply_base_character_stats() -> void:
	var profile: VesselProfile = Settings.get_selected_character()
	light_brightness = profile.light_brightness
	enemy_cast.target_position.z = -5 * profile.light_brightness


func handle_flashlight_physics(delta: float):
	if light.light_energy != target_brightness:
		flicker_light()
	
	if not point_flashlight():
		get_flashlight_offset(delta)


## Offsets flashlight rotation slightly when moving camera
## [br]Juice effect to make camera movement feel more realistic/smooth
func get_flashlight_offset(delta: float) -> void:
	# flashlight offset smoothing
	flashlight_offset = flashlight_offset.lerp(Vector3.ZERO, CAMERA_SMOOTHING / 1.5 * delta)
	flashlight.rotation.y = lerp(flashlight.rotation.y, flashlight_offset.y, CAMERA_SMOOTHING * delta)
	
	# occurs when a page is collected, holds light down briefly
	if rotation_override != 0:
		flashlight.global_rotation.x = lerp_angle(flashlight.global_rotation.x, rotation_override + flashlight_offset.x, 8 * delta)
		return
	
	# sprinting - lock to world angle by canceling out head rotation
	if movement_component.is_sprinting() or restriction_component.check_for_restriction(PlayerRestriction.RestrictionType.RADAR):
		# Set local rotation to achieve desired world angle
		var desired_world_angle = deg_to_rad(sprint_angle) + flashlight_offset.x
		var local_angle_needed = desired_world_angle - head.rotation.x
		flashlight.rotation.x = lerp_angle(flashlight.rotation.x, local_angle_needed, 10 * delta)
	# walking
	elif player.velocity.length() != 0:
		flashlight.rotation.x = lerp(flashlight.rotation.x, flashlight_offset.x + deg_to_rad(-5) + sin(time_count * 5) * 0.015, 6 * delta)
		flashlight.rotation.y = lerp(flashlight.rotation.y, flashlight_offset.y + deg_to_rad(-5) + sin(time_count * 5) * 0.015, 6 * delta)
	# standing
	else:
		flashlight.rotation.x = lerp(flashlight.rotation.x, flashlight_offset.x + cos(time_count) * 0.01, 6 * delta)


func add_camera_offset(offset: Vector3):
	flashlight_offset.x = clamp(flashlight_offset.x + offset.x, -0.5, 0.5)
	flashlight_offset.y = clamp(flashlight_offset.y + offset.y, -0.5, 0.5)


## Points flashlight at designated object and overrides the offset function
# TODO optimization
func point_flashlight() -> bool:
	if restriction_component.check_for_restriction(PlayerRestriction.RestrictionType.RADAR) \
	or restriction_component.check_for_restriction(PlayerRestriction.RestrictionType.FLASHLIGHT_ANGLE):
		return false
	
	var pos = enemy_cast.get("enemy_position")
	if pos == Vector3.ZERO:
		pos = interaction_cast.get("interactible_position")
	
	if pos and pos != Vector3.ZERO:
		var camera = camera_component.camera
		var to_target = (pos - camera.global_position).normalized()
		var camera_forward = -camera.global_transform.basis.z
		var angle = rad_to_deg(acos(clamp(to_target.dot(camera_forward), -1.0, 1.0)))
		
		if angle > ATTRACTION_MAX_ANGLE:
			return false
		
		var target_transform = flashlight.global_transform.looking_at(pos)
		var current_quat: Quaternion = Quaternion(flashlight.global_transform.basis.orthonormalized())
		var target_quat: Quaternion = Quaternion(target_transform.basis.orthonormalized())
		
		var smoothed_quat = current_quat.slerp(target_quat, CAMERA_SMOOTHING * get_physics_process_delta_time())
		flashlight.global_transform.basis = Basis(smoothed_quat)
		
		return true
	return false


func on_page_collected() -> void:
	rotation_override = deg_to_rad(sprint_angle)
	await get_tree().create_timer(PAGE_LIGHT_DOWN_TIME, false).timeout
	rotation_override = 0


func toggle_light(on: bool):
	light.visible = on
	light_on = on
	omni_light.visible = !light.visible
	flashlight.rotation.x = deg_to_rad(TURN_ON_ANGLE.x)
	flashlight.rotation.y = deg_to_rad(TURN_ON_ANGLE.y)
	enemy_cast.enabled = on and !movement_component.is_sprinting()
	play_audio()


func set_flicker_light(starting_energy: float):
	if !get_light_status():
		return
	
	flickering = true
	AudioTools.play_one_shot(get_tree(), flicker_sound, 2, randf_range(0.9, 1.1), -4.0)
	target_brightness = starting_energy
	await target_brightness_reached
	flickering = false


func flicker_light():
	if light.light_energy > target_brightness:
		light.light_energy += randf_range(-0.2, 0.05)
		
		if light.light_energy <= target_brightness:
			light.light_energy = target_brightness
			target_brightness_reached.emit()
	else:
		light.light_energy += randf_range(-0.05, 0.2)
		
		if light.light_energy >= target_brightness:
			light.light_energy = target_brightness
			target_brightness_reached.emit()


func play_audio():
	audio_source.pitch_scale = randf_range(0.9, 1.1)
	audio_source.play()


func get_sprint_angle() -> float:
	return DEFAULT_SPRINT_ANGLE + sprint_angle_modifier


func get_light_status() -> bool:
	return light_on


func activate():
	set_process(true)
	flashlight.visible = true
	
	if battery_alive:
		toggle_light(true)
	else:
		light.visible = false
		light_on = false
		omni_light.visible = true
	
	flashlight.set_process(true)


func deactivate():
	set_process(false)
	light.visible = false
	light_on = false
	omni_light.visible = false
	flashlight.visible = false
	flashlight.set_process(false)


func _on_radar_charged():
	battery_alive = true


func _on_radar_died():
	battery_alive = false
	light.visible = false
	light_on = false
	omni_light.visible = !light.visible
	enemy_cast.enabled = false


func on_enemy_spawned(type: EnemyProfile.Type):
	match type:
		EnemyProfile.Type.LETHAL:
			set_flicker_light(light.light_energy / 3)
		EnemyProfile.Type.DANGEROUS:
			set_flicker_light(light.light_energy / 1.5)
		EnemyProfile.Type.NUISANCE:
			pass
