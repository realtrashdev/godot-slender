extends Node

enum BatteryState { ALIVE, DEAD }

@export var battery_chunk_scene: PackedScene

var starting_chunks: int = 4

const BATTERY_PER_CHUNK: float = 20.0
const PAGE_CHARGE_AMOUNT: float = 20.0

const IDLE_BATTERY_LOSS: float = 0.3
const ACTIVE_BATTERY_LOSS: float = 0.5
const RINGING_BATTERY_LOSS: float = 1.0

var battery_container: HBoxContainer

var state: BatteryState = BatteryState.ALIVE
var battery_remaining: float = 45.0

var low: bool = false
var dead: bool = false


func initialize(container):
	_apply_base_character_stats()
	battery_container = container
	for i in range(starting_chunks):
		_add_chunk()
	Signals.page_collected.connect(_on_page_collected)
	Signals.radar_battery_drained.connect(remove_charge_chunks)


func activate():
	battery_remaining = _get_starting_battery()


func deactivate():
	pass


func update(delta: float, screen_state: RadarScreen.ScreenState):
	if battery_remaining > 0.0:
		_add_charge(_get_battery_loss(screen_state) * -delta)
		_check_if_dead()
		_check_if_low()
	_update_visible_chunks()


func _apply_base_character_stats() -> void:
	var profile: VesselProfile = Settings.get_selected_character()
	starting_chunks = profile.radar_battery_chunks


func _add_chunk() -> void:
	var chunk = battery_chunk_scene.instantiate()
	battery_container.add_child(chunk)


# Public methods
func get_battery_state() -> BatteryState:
	return state


func get_battery_remaining() -> float:
	return battery_remaining


func remove_charge_chunks(amount: int, perma: bool):
	if perma and not _get_chunks().is_empty():
		_get_chunks()[_get_chunks().size() - 1].queue_free()
	else:
		_add_charge(-BATTERY_PER_CHUNK * amount)


# Private methods
func _get_chunks() -> Array[Node]:
	if not battery_container: return []
	return battery_container.get_children()


func _get_visible_chunks() -> int:
	return ceili(battery_remaining / BATTERY_PER_CHUNK)


func _update_visible_chunks() -> void:
	var remaining = _get_visible_chunks()
	for child: ProgressBar in _get_chunks():
		if remaining == 0:
			child.modulate = Color.TRANSPARENT
			continue
		if remaining == 1:
			child.modulate = Color.WHITE
			child.value = fmod(battery_remaining, BATTERY_PER_CHUNK)
			remaining -= 1
			continue
		child.modulate = Color.WHITE
		child.value = BATTERY_PER_CHUNK
		remaining -= 1


func _get_maximum_battery() -> float:
	return BATTERY_PER_CHUNK * float(_get_chunks().size())


func _get_starting_battery() -> float:
	return BATTERY_PER_CHUNK * float(_get_chunks().size() - 1)


func _get_battery_loss(screen_state: RadarScreen.ScreenState):
	match screen_state:
		RadarScreen.ScreenState.OFF:
			return 0.0
		RadarScreen.ScreenState.IDLE:
			return IDLE_BATTERY_LOSS
		RadarScreen.ScreenState.ACTIVE:
			return ACTIVE_BATTERY_LOSS
		RadarScreen.ScreenState.RINGING:
			return RINGING_BATTERY_LOSS


func _add_charge(charge: float):
	battery_remaining += charge
	
	# check for overflow
	if battery_remaining > _get_maximum_battery():
		battery_remaining = _get_maximum_battery()
	elif battery_remaining < 0.0:
		battery_remaining = 0.0
	
	if battery_remaining > BATTERY_PER_CHUNK and low:
		low = false
	if battery_remaining > 0 and state == BatteryState.DEAD:
		state = BatteryState.ALIVE
		dead = false
		print("Radar alive")
		Signals.radar_charged.emit()


func _check_if_low() -> bool:
	if low: return true
	if battery_remaining > 0 and battery_remaining <= BATTERY_PER_CHUNK:
		low = true
		Signals.radar_battery_low.emit()
		print("Radar low on battery")
		return true
	return false


func _check_if_dead() -> bool:
	if dead: return true
	if battery_remaining <= 0 and not state == BatteryState.DEAD:
		state = BatteryState.DEAD
		Signals.radar_died.emit()
		dead = true
		low = false
		print("Radar died")
		return true
	return false


func _on_page_collected():
	_add_charge(PAGE_CHARGE_AMOUNT)
